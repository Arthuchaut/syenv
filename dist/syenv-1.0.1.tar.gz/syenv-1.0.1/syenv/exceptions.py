class SysenvError(Exception):
    """The error generic exception for the Syenv class."""

    ...
